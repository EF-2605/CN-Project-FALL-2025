#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>

#define SERVER_IP "127.0.0.1"
#define TCP_PORT 8080
#define UDP_PORT 8081
#define BUFFER_SIZE 1024

int tcp_socket, udp_socket;
int running = 1;
char campus_name[20];
int my_udp_port = 0;

// Get timestamp
void get_timestamp(char* buffer) {
    time_t rawtime;
    struct tm* timeinfo;
    
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(buffer, 20, "%H:%M:%S", timeinfo);
}

// Create UDP socket and get port
int create_udp_socket() {
    struct sockaddr_in udp_addr;
    
    udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if(udp_socket < 0) {
        return -1;
    }
    
    // Bind to any available port
    memset(&udp_addr, 0, sizeof(udp_addr));
    udp_addr.sin_family = AF_INET;
    udp_addr.sin_addr.s_addr = INADDR_ANY;
    udp_addr.sin_port = 0;  // Let OS choose port
    
    if(bind(udp_socket, (struct sockaddr*)&udp_addr, sizeof(udp_addr)) < 0) {
        close(udp_socket);
        return -1;
    }
    
    // Get the assigned port number
    socklen_t len = sizeof(udp_addr);
    getsockname(udp_socket, (struct sockaddr*)&udp_addr, &len);
    my_udp_port = ntohs(udp_addr.sin_port);
    
    printf("UDP socket created on port %d\n", my_udp_port);
    return 0;
}

// Connect to server
int connect_to_server() {
    struct sockaddr_in server_addr;
    
    tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
    if(tcp_socket < 0) {
        printf("TCP socket failed\n");
        return -1;
    }
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(TCP_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);
    
    if(connect(tcp_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        printf("Connection failed\n");
        return -1;
    }
    
    printf("Connected to Central Server\n");
    return 0;
}

// Authenticate with hard-coded password
int authenticate_campus() {
    char auth_msg[100];
    char response[50];
    
    printf("=== Campus Login ===\n");
    printf("Enter campus (Lahore/Karachi/Peshawar/CFD/Multan): ");
    fgets(campus_name, sizeof(campus_name), stdin);
    campus_name[strcspn(campus_name, "\n")] = '\0';
    
    // Hard-code passwords based on campus
    char password[20];
    if(strcmp(campus_name, "Lahore") == 0) strcpy(password, "NU-LHR-123");
    else if(strcmp(campus_name, "Karachi") == 0) strcpy(password, "NU-KHI-123");
    else if(strcmp(campus_name, "Peshawar") == 0) strcpy(password, "NU-PSH-123");
    else if(strcmp(campus_name, "CFD") == 0) strcpy(password, "NU-CFD-123");
    else if(strcmp(campus_name, "Multan") == 0) strcpy(password, "NU-MTN-123");
    else {
        printf("Invalid campus name\n");
        return 0;
    }
    
    printf("Using password: %s\n", password);
    
    // Create UDP socket first
    if(create_udp_socket() < 0) {
        printf("UDP socket failed\n");
        return 0;
    }
    
    // Send BOTH campus, password AND UDP port in ONE message
    snprintf(auth_msg, sizeof(auth_msg), "Campus:%s,Pass:%s,UDP:%d", 
             campus_name, password, my_udp_port);
    
    printf("Sending auth: %s\n", auth_msg);
    send(tcp_socket, auth_msg, strlen(auth_msg), 0);
    
    // Get authentication response
    int bytes = recv(tcp_socket, response, sizeof(response) - 1, 0);
    if(bytes > 0) {
        response[bytes] = '\0';
        if(strcmp(response, "AUTH_SUCCESS") == 0) {
            printf("Authentication successful! Welcome %s campus.\n", campus_name);
            return 1;
        } else {
            printf("Authentication failed: %s\n", response);
            return 0;
        }
    }
    
    printf("No response from server\n");
    return 0;
}

// Send heartbeat to server
void* send_heartbeat(void* arg) {
    struct sockaddr_in server_addr;
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(UDP_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);
    
    // Set socket to receive broadcasts
    int broadcast_enable = 1;
    setsockopt(udp_socket, SOL_SOCKET, SO_BROADCAST, &broadcast_enable, sizeof(broadcast_enable));
    
    // Allow reuse address
    int reuse = 1;
    setsockopt(udp_socket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    
    // Set receive timeout
    struct timeval tv;
    tv.tv_sec = 1;
    tv.tv_usec = 0;
    setsockopt(udp_socket, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    
    while(running) {
        // Send heartbeat
        char heartbeat[50];
        snprintf(heartbeat, sizeof(heartbeat), "%s:HEARTBEAT:%d", campus_name, my_udp_port);
        sendto(udp_socket, heartbeat, strlen(heartbeat), 0,
              (struct sockaddr*)&server_addr, sizeof(server_addr));
        
        // Listen for broadcasts (non-blocking)
        char buffer[BUFFER_SIZE];
        struct sockaddr_in sender_addr;
        socklen_t addr_len = sizeof(sender_addr);
        
        int bytes = recvfrom(udp_socket, buffer, BUFFER_SIZE, 0,
                           (struct sockaddr*)&sender_addr, &addr_len);
        
        if(bytes > 0) {
            buffer[bytes] = '\0';
            
            // Check if it's a broadcast from server
            if(strstr(buffer, "ADMIN BROADCAST:") != NULL) {
                printf("\n══════════════════════════════════════════\n");
                printf("%s\n", buffer);
                printf("══════════════════════════════════════════\n");
                printf("Enter choice: ");
                fflush(stdout);
            }
        }
        
        sleep(10);  // Every 10 seconds
    }
    
    close(udp_socket);
    return NULL;
}

// Listen for TCP messages
void* listen_tcp_messages(void* arg) {
    fd_set readfds;
    char buffer[BUFFER_SIZE];
    
    while(running) {
        FD_ZERO(&readfds);
        FD_SET(tcp_socket, &readfds);
        
        struct timeval tv;
        tv.tv_sec = 1;
        tv.tv_usec = 0;
        
        int ready = select(tcp_socket + 1, &readfds, NULL, NULL, &tv);
        
        if(ready > 0 && FD_ISSET(tcp_socket, &readfds)) {
            int bytes = recv(tcp_socket, buffer, BUFFER_SIZE, 0);
            
            if(bytes > 0) {
                buffer[bytes] = '\0';
                printf("\n══════════════════════════════════════════\n");
                printf("DIRECT MESSAGE:\n%s\n", buffer);
                printf("══════════════════════════════════════════\n");
                printf("Enter choice: ");
                fflush(stdout);
            }
            else if(bytes == 0) {
                printf("\nServer disconnected!\n");
                running = 0;
                break;
            }
        }
    }
    
    return NULL;
}

// Send message to another campus
void send_message() {
    char target[20], dept[20], message[200];
    
    printf("\n--- Send Message ---\n");
    printf("Target campus: ");
    fgets(target, sizeof(target), stdin);
    target[strcspn(target, "\n")] = '\0';
    
    printf("Department: ");
    fgets(dept, sizeof(dept), stdin);
    dept[strcspn(dept, "\n")] = '\0';
    
    printf("Message: ");
    fgets(message, sizeof(message), stdin);
    message[strcspn(message, "\n")] = '\0';
    
    char formatted[300];
    snprintf(formatted, sizeof(formatted), "TO:%s:%s:%s", target, dept, message);
    
    send(tcp_socket, formatted, strlen(formatted), 0);
    
    // Get response
    char response[50];
    int bytes = recv(tcp_socket, response, sizeof(response) - 1, 0);
    if(bytes > 0) {
        response[bytes] = '\0';
        printf("Server: %s\n", response);
    }
}

// Main menu
void campus_menu() {
    char choice[10];
    
    while(running) {
        printf("\n=== %s CAMPUS ===\n", campus_name);
        printf("1. Send message\n");
        printf("2. Check messages\n");
        printf("3. Disconnect\n");
        printf("Choice: ");
        
        fgets(choice, sizeof(choice), stdin);
        choice[strcspn(choice, "\n")] = '\0';
        
        if(strcmp(choice, "1") == 0) {
            send_message();
        }
        else if(strcmp(choice, "2") == 0) {
            printf("Messages appear automatically above\n");
        }
        else if(strcmp(choice, "3") == 0) {
            send(tcp_socket, "EXIT", 4, 0);
            running = 0;
            printf("Disconnecting...\n");
            break;
        }
    }
}

int main() {
    printf("=== FAST-NUCES Campus Client ===\n");
    
    if(connect_to_server() < 0) {
        return 1;
    }
    
    if(!authenticate_campus()) {
        close(tcp_socket);
        return 1;
    }
    
    // Start heartbeat thread
    pthread_t heartbeat_tid;
    pthread_create(&heartbeat_tid, NULL, send_heartbeat, NULL);
    
    // Start TCP listener thread
    pthread_t tcp_tid;
    pthread_create(&tcp_tid, NULL, listen_tcp_messages, NULL);
    
    // Start menu
    campus_menu();
    
    // Cleanup
    running = 0;
    pthread_join(heartbeat_tid, NULL);
    pthread_join(tcp_tid, NULL);
    
    close(tcp_socket);
    printf("Client terminated\n");
    
    return 0;
}
