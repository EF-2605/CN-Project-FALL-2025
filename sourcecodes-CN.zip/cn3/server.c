#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>

#define MAX_CLIENTS 10
#define TCP_PORT 8080
#define UDP_PORT 8081
#define BUFFER_SIZE 1024

typedef struct {
    int socket_fd;
    char campus_name[20];
    int authenticated;
    struct sockaddr_in tcp_addr;
    struct sockaddr_in udp_addr;  // Store UDP address for broadcasts
    time_t last_heartbeat;
} CampusInfo;

CampusInfo campuses[MAX_CLIENTS];
int campus_count = 0;
pthread_mutex_t campus_mutex = PTHREAD_MUTEX_INITIALIZER;

// Get timestamp
void get_timestamp(char* buffer) {
    time_t rawtime;
    struct tm* timeinfo;
    
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(buffer, 20, "%H:%M:%S", timeinfo);
}

// Add campus
void add_campus(int socket_fd, char* campus_name, struct sockaddr_in tcp_addr, struct sockaddr_in udp_addr) {
    pthread_mutex_lock(&campus_mutex);
    
    for(int i = 0; i < MAX_CLIENTS; i++) {
        if(campuses[i].socket_fd == 0) {
            campuses[i].socket_fd = socket_fd;
            strcpy(campuses[i].campus_name, campus_name);
            campuses[i].authenticated = 1;
            campuses[i].tcp_addr = tcp_addr;
            campuses[i].udp_addr = udp_addr;
            campuses[i].last_heartbeat = time(NULL);
            campus_count++;
            
            char timestamp[20];
            get_timestamp(timestamp);
            printf("[%s] %s campus connected\n", timestamp, campus_name);
            break;
        }
    }
    
    pthread_mutex_unlock(&campus_mutex);
}

// Remove campus
void remove_campus(int socket_fd) {
    pthread_mutex_lock(&campus_mutex);
    
    for(int i = 0; i < MAX_CLIENTS; i++) {
        if(campuses[i].socket_fd == socket_fd) {
            char timestamp[20];
            get_timestamp(timestamp);
            printf("[%s] %s campus disconnected\n", timestamp, campuses[i].campus_name);
            
            campuses[i].socket_fd = 0;
            campuses[i].authenticated = 0;
            campus_count--;
            break;
        }
    }
    
    pthread_mutex_unlock(&campus_mutex);
}

// Update UDP address when heartbeat received
void update_udp_addr(char* campus_name, struct sockaddr_in udp_addr) {
    pthread_mutex_lock(&campus_mutex);
    
    for(int i = 0; i < MAX_CLIENTS; i++) {
        if(campuses[i].authenticated && strcmp(campuses[i].campus_name, campus_name) == 0) {
            campuses[i].udp_addr = udp_addr;
            campuses[i].last_heartbeat = time(NULL);
            break;
        }
    }
    
    pthread_mutex_unlock(&campus_mutex);
}

// Send broadcast to all campuses
void send_broadcast_to_all(char* message) {
    pthread_mutex_lock(&campus_mutex);
    
    int broadcast_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if(broadcast_socket < 0) {
        perror("Broadcast socket failed");
        pthread_mutex_unlock(&campus_mutex);
        return;
    }
    
    // Enable broadcast option
    int broadcast_enable = 1;
    setsockopt(broadcast_socket, SOL_SOCKET, SO_BROADCAST, &broadcast_enable, sizeof(broadcast_enable));
    
    char broadcast_msg[300];
    char timestamp[20];
    get_timestamp(timestamp);
    snprintf(broadcast_msg, sizeof(broadcast_msg), 
             "[%s] ADMIN BROADCAST: %s", timestamp, message);
    
    printf("Sending broadcast to %d campuses...\n", campus_count);
    
    // Send to each campus individually (more reliable than network broadcast)
    for(int i = 0; i < MAX_CLIENTS; i++) {
        if(campuses[i].authenticated) {
            // Send to the UDP address where heartbeats come from
            sendto(broadcast_socket, broadcast_msg, strlen(broadcast_msg), 0,
                  (struct sockaddr*)&campuses[i].udp_addr, sizeof(campuses[i].udp_addr));
            
            printf("  -> Sent to %s at %s:%d\n", 
                   campuses[i].campus_name,
                   inet_ntoa(campuses[i].udp_addr.sin_addr),
                   ntohs(campuses[i].udp_addr.sin_port));
        }
    }
    
    close(broadcast_socket);
    pthread_mutex_unlock(&campus_mutex);
}

// Route TCP message
void route_message(int src_socket, char* message) {
    char target_campus[20], target_dept[20], msg_content[200];
    
    if(sscanf(message, "TO:%[^:]:%[^:]:%[^\n]", target_campus, target_dept, msg_content) != 3) {
        send(src_socket, "ERROR: Invalid format", 21, 0);
        return;
    }
    
    // Find target campus
    int dest_socket = -1;
    char src_name[20] = "Unknown";
    
    pthread_mutex_lock(&campus_mutex);
    for(int i = 0; i < MAX_CLIENTS; i++) {
        if(campuses[i].socket_fd == src_socket) {
            strcpy(src_name, campuses[i].campus_name);
        }
        if(campuses[i].authenticated && strcmp(campuses[i].campus_name, target_campus) == 0) {
            dest_socket = campuses[i].socket_fd;
        }
    }
    pthread_mutex_unlock(&campus_mutex);
    
    if(dest_socket == -1) {
        send(src_socket, "ERROR: Campus not connected", 27, 0);
        return;
    }
    
    char formatted_msg[300];
    char timestamp[20];
    get_timestamp(timestamp);
    snprintf(formatted_msg, sizeof(formatted_msg), 
             "[%s] From %s to %s:%s\nMessage: %s", 
             timestamp, src_name, target_campus, target_dept, msg_content);
    
    send(dest_socket, formatted_msg, strlen(formatted_msg), 0);
    send(src_socket, "Message delivered", 17, 0);
    
    printf("[%s] Routed: %s -> %s\n", timestamp, src_name, target_campus);
}

// Handle TCP client with password authentication
void* handle_campus(void* arg) {
    int client_socket = *((int*)arg);
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];
    
    getpeername(client_socket, (struct sockaddr*)&client_addr, &addr_len);
    
    // Get authentication data (ONE message with everything)
    int bytes = recv(client_socket, buffer, BUFFER_SIZE, 0);
    if(bytes <= 0) {
        close(client_socket);
        free(arg);
        return NULL;
    }
    buffer[bytes] = '\0';
    
    printf("Received auth: %s\n", buffer);
    
    // Parse campus, password AND UDP port from ONE message
    // Format: "Campus:Lahore,Pass:NU-LHR-123,UDP:44637"
    char campus_name[20], password[20];
    int udp_port;
    
    if(sscanf(buffer, "Campus:%[^,],Pass:%[^,],UDP:%d", 
              campus_name, password, &udp_port) != 3) {
        send(client_socket, "AUTH_FAILED:Bad format", 23, 0);
        close(client_socket);
        free(arg);
        return NULL;
    }
    
    printf("Parsed: Campus=%s, Password=%s, UDP Port=%d\n", 
           campus_name, password, udp_port);
    
    // Check password based on campus
    int valid_pass = 0;
    if(strcmp(campus_name, "Lahore") == 0 && strcmp(password, "NU-LHR-123") == 0) valid_pass = 1;
    else if(strcmp(campus_name, "Karachi") == 0 && strcmp(password, "NU-KHI-123") == 0) valid_pass = 1;
    else if(strcmp(campus_name, "Peshawar") == 0 && strcmp(password, "NU-PSH-123") == 0) valid_pass = 1;
    else if(strcmp(campus_name, "CFD") == 0 && strcmp(password, "NU-CFD-123") == 0) valid_pass = 1;
    else if(strcmp(campus_name, "Multan") == 0 && strcmp(password, "NU-MTN-123") == 0) valid_pass = 1;
    
    if(!valid_pass) {
        send(client_socket, "AUTH_FAILED:Wrong password", 27, 0);
        close(client_socket);
        free(arg);
        return NULL;
    }
    
    // Create UDP address for this client
    struct sockaddr_in udp_addr;
    memcpy(&udp_addr, &client_addr, sizeof(client_addr));
    udp_addr.sin_port = htons(udp_port);
    
    // Send authentication success
    send(client_socket, "AUTH_SUCCESS", 12, 0);
    
    // Add to connected campuses
    add_campus(client_socket, campus_name, client_addr, udp_addr);
    
    // Handle messages from campus
    while(1) {
        bytes = recv(client_socket, buffer, BUFFER_SIZE, 0);
        if(bytes <= 0) break;
        
        buffer[bytes] = '\0';
        
        if(strncmp(buffer, "TO:", 3) == 0) {
            route_message(client_socket, buffer);
        }
        else if(strcmp(buffer, "EXIT") == 0) {
            break;
        }
    }
    
    remove_campus(client_socket);
    close(client_socket);
    free(arg);
    return NULL;
}

// UDP handler for heartbeats
void* handle_udp(void* arg) {
    int udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];
    
    // Setup UDP socket
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(UDP_PORT);
    
    if(bind(udp_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("UDP bind failed");
        return NULL;
    }
    
    printf("UDP server listening on port %d\n", UDP_PORT);
    
    while(1) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytes = recvfrom(udp_socket, buffer, BUFFER_SIZE, 0,
                            (struct sockaddr*)&client_addr, &addr_len);
        
        if(bytes > 0) {
            buffer[bytes] = '\0';
            
            // Check message type
            if(strstr(buffer, ":HEARTBEAT:") != NULL) {
                // Format: "Campus:HEARTBEAT:UDP_PORT"
                char campus_name[20];
                int udp_port;
                sscanf(buffer, "%[^:]:HEARTBEAT:%d", campus_name, &udp_port);
                
                // Update client's UDP address
                client_addr.sin_port = htons(udp_port);
                update_udp_addr(campus_name, client_addr);
                
                char timestamp[20];
                get_timestamp(timestamp);
                printf("[%s] Heartbeat from %s\n", 
                       timestamp, campus_name);
            }
        }
    }
    
    close(udp_socket);
    return NULL;
}

// Admin console
void admin_console() {
    char command[100];
    
    while(1) {
        printf("\n=== ISLAMABAD ADMIN ===\n");
        printf("1. Show connected campuses\n");
        printf("2. Send broadcast to all campuses\n");
        printf("3. Check status\n");
        printf("4. Exit admin\n");
        printf("Choice: ");
        
        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = '\0';
        
        if(strcmp(command, "1") == 0) {
            pthread_mutex_lock(&campus_mutex);
            printf("\nConnected Campuses (%d):\n", campus_count);
            for(int i = 0; i < MAX_CLIENTS; i++) {
                if(campuses[i].authenticated) {
                    printf("  %s (TCP: %d, UDP: %d)\n", 
                           campuses[i].campus_name,
                           campuses[i].socket_fd,
                           ntohs(campuses[i].udp_addr.sin_port));
                }
            }
            pthread_mutex_unlock(&campus_mutex);
        }
        else if(strcmp(command, "2") == 0) {
            printf("Enter broadcast message: ");
            fgets(command, sizeof(command), stdin);
            command[strcspn(command, "\n")] = '\0';
            
            send_broadcast_to_all(command);
            printf("Broadcast sent!\n");
        }
        else if(strcmp(command, "3") == 0) {
            pthread_mutex_lock(&campus_mutex);
            printf("\nCampus Status:\n");
            time_t now = time(NULL);
            for(int i = 0; i < MAX_CLIENTS; i++) {
                if(campuses[i].authenticated) {
                    int seconds = now - campuses[i].last_heartbeat;
                    printf("  %s: Active (last seen %d sec ago)\n", 
                           campuses[i].campus_name, seconds);
                }
            }
            pthread_mutex_unlock(&campus_mutex);
        }
        else if(strcmp(command, "4") == 0) {
            break;
        }
    }
}

int main() {
    printf("=== FAST-NUCES Central Server (Islamabad) ===\n");
    printf("Using hard-coded password authentication\n");
    
    int server_fd, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    
    memset(campuses, 0, sizeof(campuses));
    
    // Create TCP socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(TCP_PORT);
    
    if(bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        return 1;
    }
    
    listen(server_fd, 5);
    printf("TCP server on port %d\n", TCP_PORT);
    
    // Start UDP thread
    pthread_t udp_thread;
    pthread_create(&udp_thread, NULL, handle_udp, NULL);
    
    // Start admin in background
    pthread_t admin_thread;
    pthread_create(&admin_thread, NULL, (void*)admin_console, NULL);
    
    // Accept clients
    while(1) {
        client_socket = accept(server_fd, (struct sockaddr*)&client_addr, &addr_len);
        if(client_socket < 0) continue;
        
        printf("New connection from %s:%d\n", 
               inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
        
        pthread_t thread;
        int* new_sock = malloc(sizeof(int));
        *new_sock = client_socket;
        
        pthread_create(&thread, NULL, handle_campus, (void*)new_sock);
        pthread_detach(thread);
    }
    
    close(server_fd);
    return 0;
}
